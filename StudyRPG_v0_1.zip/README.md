# Study RPG v0.1
A small offline-first Android MVP.

Core loop:
Study task -> XP -> level/mastery -> gaming-time reward.

This version intentionally does NOT include AccessibilityService, Device Admin, or app blocking.
Open in Android Studio and sync/build the project.
