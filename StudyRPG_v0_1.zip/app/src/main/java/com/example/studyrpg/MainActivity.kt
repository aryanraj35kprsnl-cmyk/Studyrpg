package com.example.studyrpg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

data class Chapter(val subject: String, val name: String, val mastery: Int, val xp: Int)

class StudyViewModel : ViewModel() {
    var totalXp by mutableIntStateOf(0); private set
    var gamingMinutes by mutableIntStateOf(0); private set
    var chapters by mutableStateOf(
        listOf(
            Chapter("Mathematics", "Relations", 0, 0),
            Chapter("Mathematics", "Functions", 0, 0),
            Chapter("Physics", "Electric Charges & Fields", 0, 0),
            Chapter("Chemistry", "Solutions", 0, 0)
        )
    ); private set

    val level: Int get() = (totalXp / 500) + 1
    val xpInLevel: Int get() = totalXp % 500
    val xpForNext: Int get() = 500

    fun completeTask(index: Int, difficulty: Int) {
        val gain = when (difficulty) { 1 -> 25; 2 -> 50; else -> 100 }
        totalXp += gain
        gamingMinutes += gain / 10
        val updated = chapters.toMutableList()
        val c = updated[index]
        updated[index] = c.copy(
            mastery = (c.mastery + difficulty * 5).coerceAtMost(100),
            xp = c.xp + gain
        )
        chapters = updated
    }
}

@Composable
fun App(vm: StudyViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = {}, label = { Text("Home") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = {}, label = { Text("Chapters") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = {}, label = { Text("Rewards") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Home(vm, Modifier.padding(padding))
                1 -> Chapters(vm, Modifier.padding(padding))
                2 -> Rewards(vm, Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Home(vm: StudyViewModel, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("STUDY RPG", style = MaterialTheme.typography.headlineMedium)
        Text("Level ${vm.level}", style = MaterialTheme.typography.headlineLarge)
        LinearProgressIndicator({ vm.xpInLevel / vm.xpForNext.toFloat() }, Modifier.fillMaxWidth())
        Text("${vm.xpInLevel} / ${vm.xpForNext} XP")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Gaming Time", style = MaterialTheme.typography.titleMedium)
                Text("${vm.gamingMinutes} minutes", style = MaterialTheme.typography.headlineSmall)
                Text("Earn 10 minutes for every 100 XP.")
            }
        }
        Text("Quick Mission", style = MaterialTheme.typography.titleLarge)
        Text("Complete a study task from Chapters to earn XP.")
    }
}

@Composable
fun Chapters(vm: StudyViewModel, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Chapters", style = MaterialTheme.typography.headlineMedium) }
        items(vm.chapters.indices.toList()) { i ->
            val c = vm.chapters[i]
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(c.subject, style = MaterialTheme.typography.labelLarge)
                    Text(c.name, style = MaterialTheme.typography.titleLarge)
                    LinearProgressIndicator(c.mastery / 100f, Modifier.fillMaxWidth())
                    Text("Mastery ${c.mastery}%  •  ${c.xp} XP")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ vm.completeTask(i, 1) }) { Text("+25 XP") }
                        Button({ vm.completeTask(i, 2) }) { Text("+50 XP") }
                        Button({ vm.completeTask(i, 3) }) { Text("+100 XP") }
                    }
                }
            }
        }
    }
}

@Composable
fun Rewards(vm: StudyViewModel, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Rewards", style = MaterialTheme.typography.headlineMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("COD Mobile", style = MaterialTheme.typography.titleLarge)
                Text("Unlock requirement: 80% mastery in any chapter")
                val best = vm.chapters.maxOf { it.mastery }
                Text("Best mastery: $best%")
                if (best >= 80) Text("UNLOCKED • ${vm.gamingMinutes} min available")
                else Text("LOCKED • Keep studying to unlock")
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(viewModel()) }
    }
}
